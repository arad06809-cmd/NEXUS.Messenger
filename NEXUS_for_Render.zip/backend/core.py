#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NEXO - پیام‌رسان فارسی (تک‌فایل) | Flask + SQLite (+ Flask-SocketIO اختیاری) + PWA
اجرا:  pip install flask flask-socketio simple-websocket   سپس   python nexo.py
(اگر flask-socketio نصب نباشد، برنامه با همگام‌سازی سریع HTTP کار می‌کند.)
متغیرهای محیطی: NEXO_OPENROUTER_KEY  NEXO_ADMIN (نام‌کاربری مدیر اصلی)  PORT
"""
import os, re, io, json, time, hmac, uuid, base64, struct, sqlite3, secrets, threading, traceback, urllib.request, functools
from flask import Flask, request, jsonify, session, g, send_from_directory, Response
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.exceptions import HTTPException
try:
    from flask_socketio import SocketIO, join_room
    SIO = True
except Exception:
    SIO = False

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB = os.path.join(BASE, 'nexo.db'); UP = os.path.join(BASE, 'uploads'); BK = os.path.join(BASE, 'backups')
os.makedirs(UP, exist_ok=True); os.makedirs(BK, exist_ok=True)
KF = os.path.join(BASE, '.nexo_secret')
if not os.path.exists(KF):
    open(KF, 'w').write(secrets.token_hex(32))
app = Flask(__name__, template_folder=os.path.join(BASE, 'templates'), static_folder=os.path.join(BASE, 'static'), static_url_path='/static')
app.secret_key = os.environ.get('NEXO_SECRET_KEY') or open(KF).read().strip()
app.config.update(MAX_CONTENT_LENGTH=64 * 1024 * 1024, SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax',
                  PERMANENT_SESSION_LIFETIME=60 * 60 * 24 * 30, JSON_AS_ASCII=False)
now = lambda: int(time.time())

SCHEMA = '''
create table if not exists users(id integer primary key autoincrement, username text unique collate nocase, phone text unique, nick text, pw text, bio text default '', birth text, avatar text, premium_until int default 0, stars int default 0, role text default 'user', banned int default 0, created int, last_seen int default 0, theme text, prefs text default '{}', privacy text default '{}', totp text, recov text, daily int default 0, invited_by int, ai_prefs text default '{}');
create table if not exists chats(id integer primary key autoincrement, type text, title text, owner int, username text unique collate nocase, public int default 0, avatar text, about text default '', created int);
create table if not exists members(chat_id int, user_id int, role text default 'member', pinned int default 0, muted int default 0, archived int default 0, folder int, last_read int default 0, delivered int default 0, cleared int default 0, hidden int default 0, primary key(chat_id,user_id));
create table if not exists messages(id integer primary key autoincrement, chat_id int, sender int, text text, kind text default 'text', file text, reply_to int, fwd text, edited int default 0, deleted int default 0, pinned int default 0, created int, expire_at int, upd int);
create index if not exists mi on messages(chat_id,id);
create table if not exists reactions(msg_id int, user_id int, emoji text, primary key(msg_id,user_id));
create table if not exists contacts(owner int, contact int, primary key(owner,contact));
create table if not exists blocks(owner int, blocked int, primary key(owner,blocked));
create table if not exists sessions(id text primary key, user int, device text, ip text, created int, last int, revoked int default 0);
create table if not exists files(name text primary key, orig text, size int, owner int, kind text, created int);
create table if not exists folders(id integer primary key autoincrement, user int, name text);
create table if not exists stars_tx(id integer primary key autoincrement, user int, delta int, reason text, admin int, ref text, created int);
create table if not exists gifts(id integer primary key autoincrement, name text, emoji text, price int, premium_only int default 0, rare int default 0, active int default 1);
create table if not exists user_gifts(id integer primary key autoincrement, to_user int, from_user int, gift int, note text, created int);
create table if not exists ads(id integer primary key autoincrement, user int, title text, body text, link text, status text default 'pending', views int default 0, clicks int default 0, created int);
create table if not exists reports(id integer primary key autoincrement, reporter int, kind text, target int, reason text, status text default 'open', created int);
create table if not exists audit(id integer primary key autoincrement, actor int, kind text, action text, detail text, created int);
create table if not exists errors(id integer primary key autoincrement, path text, err text, created int);
create table if not exists ai_msgs(id integer primary key autoincrement, user int, role text, content text, created int);
create table if not exists ai_mem(id integer primary key autoincrement, user int, text text);
create table if not exists ai_usage(id integer primary key autoincrement, user int, model text, tokens int, created int);
create table if not exists posts(id integer primary key autoincrement, user int, text text, file text, archived int default 0, created int);
create table if not exists settings(k text primary key, v text);
create table if not exists ctr(n int);
'''
RULES = """۱. به حریم خصوصی دیگران احترام بگذارید.
۲. ارسال محتوای غیرقانونی، خشونت‌آمیز، آزاردهنده یا کلاهبرداری ممنوع است.
۳. هرزنگاری و ارسال انبوه پیام ممنوع است.
۴. مسئولیت امنیت رمز عبور و کد بازیابی با شماست.
۵. Stars فقط اعتبار داخلی NEXO است و ارزش پولی واقعی ندارد.
۶. مدیران می‌توانند حساب‌های متخلف را مسدود کنند."""
GIFTS = [('قلب', '❤️', 5, 0, 0), ('گل', '🌹', 10, 0, 0), ('کیک', '🎂', 25, 0, 0), ('ستاره', '⭐', 50, 0, 0),
         ('الماس', '💎', 500, 0, 1), ('تاج', '👑', 300, 1, 0), ('موشک', '🚀', 150, 1, 0),
         ('خرس', '🧸', 15, 0, 0), ('جعبه هدیه', '🎁', 25, 0, 0), ('جام', '🏆', 100, 0, 0), ('گلدان', '🌷', 20, 0, 0),
         ('قلب روبانی', '💝', 40, 0, 0), ('ماه', '🌙', 250, 1, 1), ('اژدها', '🐉', 400, 1, 1)]
STAR_PACKS = [50, 100, 250, 500, 1000, 2500]
STICKERS = ['😀', '😂', '😍', '🥳', '😎', '😭', '😡', '👍', '🙏', '❤️', '🔥', '🎉']
PSTICKERS = ['🦄', '🐉', '🪐', '🌈', '👑', '💎']
REACT = ['👍', '❤️', '😂', '😮', '😢', '🙏']
PREACT = ['🔥', '💎', '🚀', '👑']
PLANS = {'m1': [30, 150], 'm3': [90, 400], 'y1': [365, 1400]}
LV = {'user': 0, 'mod': 1, 'admin': 2, 'owner': 3}
UN = re.compile(r'^[A-Za-z][A-Za-z0-9_]{3,23}$')
IMG = {'png', 'jpg', 'jpeg', 'gif', 'webp'}; VID = {'mp4', 'webm', 'mov'}; AUD = {'mp3', 'ogg', 'wav', 'm4a', 'webm', 'mp4', 'opus'}
DOC = {'pdf', 'txt', 'zip', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'csv', 'json', 'rar', '7z', 'md'}


# ---------------- database ----------------
def db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB, timeout=30); g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def _close(e):
    d = g.pop('db', None)
    if d: d.close()


def q(sql, a=(), one=False):
    r = db().execute(sql, a).fetchall()
    return (r[0] if r else None) if one else r


def x(sql, a=()):
    c = db().execute(sql, a); db().commit(); return c.lastrowid


def seq():
    db().execute('update ctr set n=n+1'); return db().execute('select n from ctr').fetchone()[0]


def S(k, d=None):
    r = q('select v from settings where k=?', (k,), True)
    return json.loads(r['v']) if r else d


def setS(k, v): x('insert or replace into settings values(?,?)', (k, json.dumps(v, ensure_ascii=False)))


def init_db():
    c = sqlite3.connect(DB); c.executescript(SCHEMA)
    if not c.execute('select count(*) from ctr').fetchone()[0]: c.execute('insert into ctr values(0)')
    have = {r[0] for r in c.execute('select name from gifts')}
    c.executemany('insert into gifts(name,emoji,price,premium_only,rare) values(?,?,?,?,?)', [g for g in GIFTS if g[0] not in have])
    c.commit(); c.close()


init_db()


# ---------------- helpers ----------------
class E(Exception):
    def __init__(s, m, c=400): s.m = m; s.c = c


def j(o=None, code=200):
    r = jsonify(o if o is not None else {'ok': True}); r.status_code = code; return r


@app.errorhandler(E)
def _e(e): return j({'error': e.m}, e.c)


@app.errorhandler(Exception)
def _ex(e):
    if isinstance(e, HTTPException):
        if e.code == 413: return j({'error': 'حجم فایل بیش از حد مجاز است'}, 413)
        return e
    try: x('insert into errors(path,err,created) values(?,?,?)', (request.path, traceback.format_exc()[-1800:], now()))
    except Exception: pass
    return j({'error': 'خطای داخلی سرور'}, 500)


RL = {}
def rl(key, n, per):
    t = time.time(); l = [a for a in RL.get(key, []) if t - a < per]
    ok = len(l) < n
    if ok: l.append(t)
    RL[key] = l; return ok


def audit(kind, action, detail='', actor=None):
    u = actor if actor is not None else (g.u['id'] if getattr(g, 'u', None) else None)
    x('insert into audit(actor,kind,action,detail,created) values(?,?,?,?,?)', (u, kind, action, str(detail)[:500], now()))


def jl(s, d=None):
    try: return json.loads(s) if s else (d if d is not None else {})
    except Exception: return d if d is not None else {}


def prem(u): return (u['premium_until'] or 0) > now()


def me():
    if hasattr(g, 'u'): return g.u
    g.u = None; sid = session.get('sid')
    if sid:
        s = q('select * from sessions where id=? and revoked=0', (sid,), True)
        u = q('select * from users where id=?', (s['user'],), True) if s else None
        if u and not u['banned']:
            g.u = u
            if now() - (u['last_seen'] or 0) > 20:
                db().execute('update users set last_seen=? where id=?', (now(), u['id']))
                db().execute('update sessions set last=? where id=?', (now(), sid)); db().commit()
    return g.u


def auth():
    u = me()
    if not u: raise E('ابتدا وارد شوید', 401)
    return u


def adm(level):
    u = auth()
    if LV.get(u['role'], 0) < LV[level]: raise E('دسترسی ندارید', 403)
    return u


@app.before_request
def _guard():
    p = request.path
    if p.startswith('/api/'):
        if not rl('ip' + (request.remote_addr or ''), 400, 60): return j({'error': 'تعداد درخواست‌ها زیاد است'}, 429)
        if request.method != 'GET':
            tok = session.get('csrf', '')
            if not tok or not hmac.compare_digest(request.headers.get('X-CSRF', ''), tok): return j({'error': 'نشست نامعتبر؛ صفحه را تازه‌سازی کنید'}, 403)


@app.after_request
def _hdr(r):
    r.headers['X-Content-Type-Options'] = 'nosniff'; r.headers['X-Frame-Options'] = 'DENY'; r.headers['Referrer-Policy'] = 'same-origin'
    if r.mimetype == 'text/html':
        r.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self' ws: wss:; frame-ancestors 'none'"
        r.headers['Cache-Control'] = 'no-store'
    return r


def phone(p):
    if not p: return None
    p = str(p).translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789'))
    p = re.sub(r'[\s\-()]', '', p)
    if p.startswith('09') and len(p) == 11: p = '+98' + p[1:]
    elif p.startswith('9') and len(p) == 10: p = '+98' + p
    elif p.startswith('0098'): p = '+' + p[2:]
    elif p.startswith('98') and len(p) == 12: p = '+' + p
    if not re.match(r'^\+\d{10,15}$', p): raise E('شماره تلفن نامعتبر است')
    return p


def online(u): return (u['last_seen'] or 0) > now() - 60


def uj(u, viewer=None, full=False):
    pv = jl(u['privacy']); self_ = viewer is not None and viewer['id'] == u['id']
    hide = pv.get('lastseen') == 'nobody' and not self_
    d = {'id': u['id'], 'username': u['username'], 'nick': u['nick'], 'avatar': u['avatar'], 'premium': prem(u), 'bio': u['bio'],
         'online': False if hide else online(u), 'last_seen': None if hide else u['last_seen'], 'role': u['role']}
    if full or self_:
        d['phone'] = u['phone'] if (self_ or pv.get('phone') != 'hide') else None
        d['birth'] = u['birth']
    if self_:
        d.update(stars=u['stars'], premium_until=u['premium_until'], theme=jl(u['theme'], None), prefs=jl(u['prefs']), privacy=pv,
                 has2fa=bool(u['totp']), email=None)
    return d


def login_user(uid):
    sid = uuid.uuid4().hex; ua = (request.headers.get('User-Agent') or '')[:160]
    x('insert into sessions(id,user,device,ip,created,last) values(?,?,?,?,?,?)', (sid, uid, ua, request.remote_addr, now(), now()))
    session['sid'] = sid; session.permanent = True
    if 'csrf' not in session: session['csrf'] = secrets.token_hex(16)


def totp(secret, t=None):
    k = base64.b32decode(secret); c = struct.pack('>Q', int((t or time.time()) // 30))
    h = hmac.new(k, c, 'sha1').digest(); o = h[-1] & 15
    return '%06d' % ((struct.unpack('>I', h[o:o + 4])[0] & 0x7fffffff) % 1000000)


def totp_ok(secret, code):
    return any(hmac.compare_digest(totp(secret, time.time() + d * 30), str(code).strip()) for d in (-1, 0, 1))


def stars_move(uid, delta, reason, admin=None, ref=None):
    c = db().execute('update users set stars=stars+? where id=? and stars+?>=0', (delta, uid, delta))
    if c.rowcount != 1: db().rollback(); raise E('موجودی Stars کافی نیست')
    db().execute('insert into stars_tx(user,delta,reason,admin,ref,created) values(?,?,?,?,?,?)', (uid, delta, reason, admin, ref, now()))


def add_premium(uid, days):
    u = q('select premium_until from users where id=?', (uid,), True)
    db().execute('update users set premium_until=? where id=?', (max(now(), u['premium_until'] or 0) + days * 86400, uid))


# ---------------- sockets ----------------
if SIO:
    sio = SocketIO(app, async_mode='threading')

    @sio.on('connect')
    def _sc():
        sid = session.get('sid'); c = sqlite3.connect(DB)
        r = c.execute('select s.user from sessions s join users u on u.id=s.user where s.id=? and s.revoked=0 and u.banned=0', (sid,)).fetchone(); c.close()
        if not r: return False
        join_room('u%d' % r[0])

    def ping(uids):
        for i in set(uids): sio.emit('sync', {}, to='u%d' % i)
else:
    def ping(uids): pass


# ---------------- pages / pwa ----------------
@app.get('/')
def index():
    session.setdefault('csrf', secrets.token_hex(16)); session.permanent = True
    html = open(os.path.join(BASE, 'templates', 'client.html'), encoding='utf-8').read()
    return Response(html.replace('__CSRF__', session['csrf']), mimetype='text/html')


@app.get('/admin')
def admin_page():
    session.setdefault('csrf', secrets.token_hex(16))
    html = open(os.path.join(BASE, 'templates', 'admin.html'), encoding='utf-8').read()
    return Response(html.replace('__CSRF__', session['csrf']), mimetype='text/html')


@app.get('/manifest.json')
def manifest():
    return j({'name': 'NEXO', 'short_name': 'NEXO', 'start_url': '/', 'display': 'standalone', 'dir': 'rtl', 'lang': 'fa',
              'background_color': '#17212b', 'theme_color': '#17212b',
              'icons': [{'src': '/icon-192.png', 'sizes': '192x192', 'type': 'image/png', 'purpose': 'any maskable'},
                        {'src': '/icon-512.png', 'sizes': '512x512', 'type': 'image/png', 'purpose': 'any maskable'}]})


@app.get('/sw.js')
def sw():
    js = """const C='nexo-files';self.addEventListener('install',e=>self.skipWaiting());self.addEventListener('activate',e=>e.waitUntil(clients.claim()));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==location.origin||!u.pathname.startsWith('/f/'))return;
e.respondWith(caches.open(C).then(async c=>{const m=await c.match(e.request);if(m)return m;const r=await fetch(e.request);if(r.status===200)c.put(e.request,r.clone());return r}))});"""
    return Response(js, mimetype='application/javascript')


_png = {}
def make_png(n):
    import zlib
    if n in _png: return _png[n]
    rows = bytearray()
    for y in range(n):
        rows.append(0)
        for xx in range(n):
            t = (xx + y) / (2 * n); r, gg, b = int(79 + 43 * t), int(125 - 39 * t), int(255 - 17 * t)
            if .28 * n <= y <= .72 * n and (.28 * n <= xx <= .37 * n or .63 * n <= xx <= .72 * n or abs(xx - (.3 * n + (y - .28 * n) * .909)) < .045 * n):
                r, gg, b = 255, 255, 255
            rows += bytes((r, gg, b))
    def ch(t, d): c = struct.pack('>I', len(d)) + t + d; return c + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    _png[n] = b'\x89PNG\r\n\x1a\n' + ch(b'IHDR', struct.pack('>IIBBBBB', n, n, 8, 2, 0, 0, 0)) + ch(b'IDAT', zlib.compress(bytes(rows), 6)) + ch(b'IEND', b'')
    return _png[n]


@app.get('/icon-<int:n>.png')
def icon(n): return Response(make_png(192 if n < 300 else 512), mimetype='image/png', headers={'Cache-Control': 'public,max-age=86400'})


@app.get('/api/rules')
def rules(): return j({'rules': S('rules', RULES)})


# ---------------- auth ----------------
@app.post('/api/register')
def register():
    d = request.get_json(silent=True) or {}
    if not S('reg_open', True): raise E('ثبت‌نام موقتاً بسته است')
    if not rl('reg' + (request.remote_addr or ''), 10, 3600): raise E('تعداد ثبت‌نام بیش از حد مجاز است', 429)
    un = (d.get('username') or '').strip(); nick = (d.get('nick') or '').strip()[:40]; pw = d.get('password') or ''
    if not UN.match(un): raise E('نام کاربری باید ۴ تا ۲۴ کاراکتر انگلیسی، عدد یا _ باشد و با حرف شروع شود')
    if not nick: raise E('نام مستعار الزامی است')
    if len(pw) < 8: raise E('رمز عبور باید حداقل ۸ کاراکتر باشد')
    if pw != d.get('password2', pw): raise E('تکرار رمز عبور مطابقت ندارد')
    ph = phone(d.get('phone')); birth = (d.get('birth') or '').strip() or None
    if birth and not re.match(r'^\d{4}-\d{2}-\d{2}$', birth): raise E('تاریخ تولد نامعتبر است')
    if q('select 1 from users where username=?', (un,)): raise E('این نام کاربری قبلاً گرفته شده')
    if ph and q('select 1 from users where phone=?', (ph,)): raise E('این شماره قبلاً ثبت شده')
    first = q('select count(*) n from users', one=True)['n'] == 0
    role = 'owner' if first or un.lower() == os.environ.get('NEXO_ADMIN', '').lower() else 'user'
    recov = secrets.token_hex(5).upper(); recov = recov[:5] + '-' + recov[5:]
    uid = x('insert into users(username,phone,nick,pw,birth,role,created,recov) values(?,?,?,?,?,?,?,?)',
            (un, ph, nick, generate_password_hash(pw), birth, role, now(), generate_password_hash(recov)))
    ref = q('select id from users where username=? and id!=?', ((d.get('ref') or '').strip(), uid), True)
    if ref:
        db().execute('update users set invited_by=? where id=?', (ref['id'], uid))
        stars_move(uid, 50, 'پاداش دعوت'); stars_move(ref['id'], 50, 'پاداش دعوت دوست: ' + un); db().commit()
    login_user(uid); audit('sec', 'register', un, uid)
    return j({'user': uj(q('select * from users where id=?', (uid,), True), me()), 'recovery': recov})


@app.post('/api/login')
def login():
    d = request.get_json(silent=True) or {}; ident = (d.get('id') or '').strip(); pw = d.get('password') or ''
    if not rl('lg' + (request.remote_addr or '') + ident.lower(), 8, 600): raise E('تلاش بیش از حد؛ چند دقیقه بعد دوباره امتحان کنید', 429)
    u = q('select * from users where username=?', (ident.lstrip('@'),), True)
    if not u:
        try: u = q('select * from users where phone=?', (phone(ident),), True)
        except E: u = None
    if not u or not check_password_hash(u['pw'], pw):
        audit('sec', 'login_fail', ident, 0); raise E('نام کاربری یا رمز عبور اشتباه است')
    if u['banned']: raise E('حساب شما مسدود شده است', 403)
    if u['totp'] and not totp_ok(u['totp'], d.get('code', '')):
        if not d.get('code'): return j({'need2fa': True})
        audit('sec', '2fa_fail', u['username'], u['id']); raise E('کد دومرحله‌ای اشتباه است')
    login_user(u['id']); audit('sec', 'login', u['username'], u['id'])
    return j({'user': uj(u, u)})


@app.post('/api/logout')
def logout():
    if session.get('sid'): x('update sessions set revoked=1 where id=?', (session['sid'],))
    session.pop('sid', None); return j()


@app.post('/api/forgot')
def forgot():
    d = request.get_json(silent=True) or {}
    if not rl('fg' + (request.remote_addr or ''), 5, 900): raise E('تلاش بیش از حد', 429)
    u = q('select * from users where username=?', ((d.get('username') or '').strip().lstrip('@'),), True)
    if not u or not check_password_hash(u['recov'] or 'x', (d.get('code') or '').strip().upper()): raise E('نام کاربری یا کد بازیابی اشتباه است')
    if len(d.get('password') or '') < 8: raise E('رمز جدید حداقل ۸ کاراکتر باشد')
    x('update users set pw=? where id=?', (generate_password_hash(d['password']), u['id']))
    x('update sessions set revoked=1 where user=?', (u['id'],)); audit('sec', 'password_reset', u['username'], u['id'])
    return j()


@app.get('/api/me')
def get_me():
    u = me(); return j({'user': uj(u, u) if u else None})


@app.post('/api/me')
def upd_me():
    u = auth(); d = request.get_json(silent=True) or {}; f = {}
    if 'nick' in d:
        if not d['nick'].strip(): raise E('نام مستعار الزامی است')
        f['nick'] = d['nick'].strip()[:40]
    if 'bio' in d: f['bio'] = (d['bio'] or '')[:200]
    if 'birth' in d:
        b = d['birth'] or None
        if b and not re.match(r'^\d{4}-\d{2}-\d{2}$', b): raise E('تاریخ تولد نامعتبر است')
        f['birth'] = b
    if 'username' in d and d['username'] != u['username']:
        if not UN.match(d['username']): raise E('نام کاربری نامعتبر است')
        if q('select 1 from users where username=? and id!=?', (d['username'], u['id'])): raise E('این نام کاربری گرفته شده')
        f['username'] = d['username']
    if 'phone' in d:
        p = phone(d['phone']) if d['phone'] else None
        if p and q('select 1 from users where phone=? and id!=?', (p, u['id'])): raise E('این شماره قبلاً ثبت شده')
        f['phone'] = p
    if 'privacy' in d:
        pv = {}
        for k, vals in (('lastseen', ('all', 'nobody')), ('phone', ('show', 'hide')), ('pm', ('all', 'contacts')), ('receipts', ('on', 'off'))):
            v = (d['privacy'] or {}).get(k)
            if v in vals: pv[k] = v
        if pv.get('receipts') == 'off' and not prem(u): raise E('مخفی‌کردن رسید خواندن مخصوص Premium است', 402)
        f['privacy'] = json.dumps({**jl(u['privacy']), **pv})
    if 'prefs' in d:
        allow = {'notif': bool, 'sound': bool, 'vol': int, 'enter': bool, 'scale': float, 'font': str, 'lang': str, 'autoimg': bool, 'autovid': bool, 'bubble': str, 'mode': str, 'accent': str}
        pf = jl(u['prefs'])
        for k, v in (d['prefs'] or {}).items():
            if k in allow and isinstance(v, (allow[k], int)): pf[k] = v if k != 'scale' else max(.85, min(1.3, float(v)))
        f['prefs'] = json.dumps(pf)
    if f:
        x('update users set ' + ','.join(k + '=?' for k in f) + ' where id=?', (*f.values(), u['id']))
    return j({'user': uj(q('select * from users where id=?', (u['id'],), True), u)})


@app.post('/api/password')
def chpw():
    u = auth(); d = request.get_json(silent=True) or {}
    if not check_password_hash(u['pw'], d.get('old') or ''): raise E('رمز فعلی اشتباه است')
    if len(d.get('new') or '') < 8: raise E('رمز جدید حداقل ۸ کاراکتر باشد')
    x('update users set pw=? where id=?', (generate_password_hash(d['new']), u['id']))
    x('update sessions set revoked=1 where user=? and id!=?', (u['id'], session['sid'])); audit('sec', 'password_change', '', u['id'])
    return j()


@app.post('/api/recovery')
def new_recovery():
    u = auth(); d = request.get_json(silent=True) or {}
    if not check_password_hash(u['pw'], d.get('password') or ''): raise E('رمز عبور اشتباه است')
    c = secrets.token_hex(5).upper(); c = c[:5] + '-' + c[5:]
    x('update users set recov=? where id=?', (generate_password_hash(c), u['id'])); return j({'recovery': c})


@app.get('/api/sessions')
def sessions():
    u = auth()
    return j([{'id': s['id'][:12], 'device': s['device'], 'ip': s['ip'], 'created': s['created'], 'last': s['last'], 'current': s['id'] == session.get('sid')}
              for s in q('select * from sessions where user=? and revoked=0 order by last desc', (u['id'],))])


@app.delete('/api/sessions/<sid>')
def kill_session(sid):
    u = auth()
    if sid == 'others': x('update sessions set revoked=1 where user=? and id!=?', (u['id'], session['sid']))
    else: x('update sessions set revoked=1 where user=? and substr(id,1,12)=? and id!=?', (u['id'], sid, session['sid']))
    return j()


@app.get('/api/2fa/setup')
def tfa_setup():
    u = auth(); sec = base64.b32encode(secrets.token_bytes(10)).decode()
    session['tfa'] = sec; return j({'secret': sec, 'uri': 'otpauth://totp/NEXO:%s?secret=%s&issuer=NEXO' % (u['username'], sec)})


@app.post('/api/2fa/enable')
def tfa_enable():
    u = auth(); d = request.get_json(silent=True) or {}
    if d.get('off'):
        if not check_password_hash(u['pw'], d.get('password') or ''): raise E('رمز عبور اشتباه است')
        x('update users set totp=null where id=?', (u['id'],)); audit('sec', '2fa_off', '', u['id']); return j()
    sec = session.get('tfa')
    if not sec or not totp_ok(sec, d.get('code', '')): raise E('کد اشتباه است')
    x('update users set totp=? where id=?', (sec, u['id'])); session.pop('tfa', None); audit('sec', '2fa_on', '', u['id']); return j()


# ---------------- files ----------------
def sniff(ext, head):
    sig = {'png': b'\x89PNG', 'jpg': b'\xff\xd8', 'jpeg': b'\xff\xd8', 'gif': b'GIF8'}
    if ext in sig: return head.startswith(sig[ext])
    if ext == 'webp': return head[:4] == b'RIFF' and head[8:12] == b'WEBP'
    return True


@app.post('/api/upload')
def upload():
    u = auth(); f = request.files.get('file'); hint = request.form.get('kind', '')
    if not f or not f.filename: raise E('فایلی انتخاب نشده')
    if not rl('up%d' % u['id'], 40, 600): raise E('آپلود بیش از حد', 429)
    ext = f.filename.rsplit('.', 1)[-1].lower() if '.' in f.filename else ''
    if hint == 'voice': kind = 'voice' if ext in AUD else None
    elif ext in IMG: kind = 'image'
    elif ext in VID: kind = 'video'
    elif ext in DOC or ext in {'mp3', 'ogg', 'wav', 'm4a'}: kind = 'file'
    else: kind = None
    if not kind: raise E('نوع فایل مجاز نیست')
    name = secrets.token_hex(16) + '.' + ext; path = os.path.join(UP, name); f.save(path); size = os.path.getsize(path)
    lim = (60 if prem(u) else 15) * 1024 * 1024
    with open(path, 'rb') as fh: head = fh.read(16)
    if size > lim or not sniff(ext, head):
        os.remove(path); raise E('حجم فایل بیش از سقف شما (%dMB) است' % (lim >> 20) if size > lim else 'محتوای فایل با پسوند مطابقت ندارد')
    x('insert into files values(?,?,?,?,?,?)', (name, os.path.basename(f.filename)[:120], size, u['id'], kind, now()))
    return j({'file': name, 'name': f.filename, 'size': size, 'kind': kind})


@app.post('/api/avatar')
def avatar():
    u = auth(); r = upload().get_json()
    if r['kind'] != 'image': raise E('فقط تصویر')
    x('update users set avatar=? where id=?', (r['file'], u['id'])); return j({'avatar': r['file']})


@app.get('/f/<name>')
def get_file(name):
    auth()
    r = q('select * from files where name=?', (name,), True)
    if not r: raise E('یافت نشد', 404)
    resp = send_from_directory(UP, name, conditional=True, as_attachment=r['kind'] == 'file', download_name=r['orig'])
    resp.headers['Content-Security-Policy'] = "sandbox; default-src 'none'"; resp.headers['Cache-Control'] = 'private,max-age=86400'
    return resp


# ---------------- users / contacts ----------------
@app.get('/api/users/<int:uid>')
def user_profile(uid):
    v = auth(); u = q('select * from users where id=?', (uid,), True)
    if not u or u['banned']: raise E('کاربر یافت نشد', 404)
    d = uj(u, v, True)
    d['gifts'] = [{'id': r['id'], 'gid': r['gid'], 'emoji': r['emoji'], 'name': r['name'], 'price': r['price'], 'rare': r['rare'], 'from': r['fn'], 'from_id': r['fid'],
                   'from_avatar': r['fa'], 'note': r['note'], 'created': r['created']} for r in q(
        'select ug.id,g.id gid,g.emoji,g.name,g.price,g.rare,u.id fid,u.nick fn,u.avatar fa,ug.note,ug.created from user_gifts ug join gifts g on g.id=ug.gift join users u on u.id=ug.from_user where ug.to_user=? order by ug.id desc limit 60', (uid,))]
    d['posts'] = [dict(r) for r in q('select id,text,file,archived,created from posts where user=? and (archived=0 or user=?) order by id desc limit 50', (uid, v['id']))]
    d['contact'] = bool(q('select 1 from contacts where owner=? and contact=?', (v['id'], uid), True))
    d['blocked'] = bool(q('select 1 from blocks where owner=? and blocked=?', (v['id'], uid), True))
    return j(d)


@app.get('/api/search')
def search():
    u = auth(); s = (request.args.get('q') or '').strip().lstrip('@')
    if len(s) < 2: return j({'users': [], 'chats': []})
    like = '%' + s.replace('%', '').replace('_', '') + '%'
    us = q('select * from users where banned=0 and id!=? and (username like ? or nick like ? or phone=?) limit 20', (u['id'], like, like, s))
    cs = q("select id,title,username,type,avatar from chats where public=1 and type!='private' and (title like ? or username like ?) limit 15", (like, like))
    return j({'users': [uj(r, u) for r in us], 'chats': [dict(r) for r in cs]})


@app.get('/api/contacts')
def contacts():
    u = auth()
    return j([uj(r, u) for r in q('select u.* from contacts c join users u on u.id=c.contact where c.owner=? and u.banned=0 order by u.nick', (u['id'],))])


@app.post('/api/contacts')
def add_contact():
    u = auth(); d = request.get_json(silent=True) or {}; t = None
    if d.get('id'): t = q('select * from users where id=?', (int(d['id']),), True)
    else:
        k = (d.get('q') or '').strip().lstrip('@'); t = q('select * from users where username=?', (k,), True)
        if not t:
            try: t = q('select * from users where phone=?', (phone(k),), True)
            except E: pass
    if not t or t['banned']: raise E('کاربری پیدا نشد')
    if t['id'] == u['id']: raise E('نمی‌توانید خودتان را اضافه کنید')
    x('insert or ignore into contacts values(?,?)', (u['id'], t['id'])); return j(uj(t, u))


@app.delete('/api/contacts/<int:cid>')
def del_contact(cid): x('delete from contacts where owner=? and contact=?', (auth()['id'], cid)); return j()


@app.get('/api/blocks')
def blocks():
    u = auth(); return j([uj(r, u) for r in q('select u.* from blocks b join users u on u.id=b.blocked where b.owner=?', (u['id'],))])


@app.post('/api/block/<int:bid>')
def block(bid): x('insert or ignore into blocks values(?,?)', (auth()['id'], bid)); return j()


@app.delete('/api/block/<int:bid>')
def unblock(bid): x('delete from blocks where owner=? and blocked=?', (auth()['id'], bid)); return j()


@app.post('/api/posts')
def add_post():
    u = auth(); d = request.get_json(silent=True) or {}
    if not (d.get('text') or d.get('file')): raise E('پست خالی است')
    if d.get('file') and not q('select 1 from files where name=? and owner=?', (d['file'], u['id']), True): raise E('فایل نامعتبر')
    x('insert into posts(user,text,file,created) values(?,?,?,?)', (u['id'], (d.get('text') or '')[:1000], d.get('file'), now())); return j()


@app.post('/api/posts/<int:pid>')
def post_op(pid):
    u = auth(); d = request.get_json(silent=True) or {}
    if not q('select 1 from posts where id=? and user=?', (pid, u['id']), True): raise E('یافت نشد', 404)
    if d.get('op') == 'delete': x('delete from posts where id=?', (pid,))
    else: x('update posts set archived=1-archived where id=?', (pid,))
    return j()


# ---------------- chats ----------------
def need_member(cid, uid):
    m = q('select * from members where chat_id=? and user_id=?', (cid, uid), True)
    if not m: raise E('دسترسی ندارید', 403)
    return m


def chat_info(c, m, uid):
    last = q('select m.*,u.nick sn from messages m join users u on u.id=m.sender where m.chat_id=? and m.id>? and m.deleted=0 and m.created<=? and (m.expire_at is null or m.expire_at>?) order by m.id desc limit 1',
             (c['id'], m['cleared'], now(), now()), True)
    unread = q('select count(*) n from messages where chat_id=? and id>? and id>? and sender!=? and deleted=0 and created<=?', (c['id'], m['last_read'], m['cleared'], uid, now()), True)['n']
    d = {'id': c['id'], 'type': c['type'], 'title': c['title'], 'avatar': c['avatar'], 'username': c['username'], 'about': c['about'], 'pinned': m['pinned'], 'muted': m['muted'],
         'archived': m['archived'], 'folder': m['folder'], 'unread': unread, 'role': m['role'], 'owner': c['owner'], 'public': c['public'],
         'ts': last['created'] if last else c['created']}
    if last:
        pre = {'text': last['text'], 'image': '🖼 تصویر', 'video': '🎬 ویدیو', 'file': '📎 فایل', 'voice': '🎤 پیام صوتی', 'sticker': last['text']}.get(last['kind'], last['text'])
        if last['kind'] == 'gift': pre = '🎁 هدیه'
        d['last'] = {'text': (pre or '')[:80], 'sender': last['sn'], 'mine': last['sender'] == uid, 'id': last['id']}
    if c['type'] == 'private':
        p = q('select u.* from members m join users u on u.id=m.user_id where m.chat_id=? and m.user_id!=?', (c['id'], uid), True)
        if p:
            pu = uj(p, me()); d.update(title=p['nick'], avatar=p['avatar'], peer=pu)
    return d


@app.get('/api/chats')
def chats():
    u = auth(); uid = u['id']
    db().execute('update members set delivered=(select coalesce(max(id),0) from messages where chat_id=members.chat_id) where user_id=?', (uid,)); db().commit()
    rows = q('select c.*, m.pinned,m.muted,m.archived,m.folder,m.last_read,m.role mrole,m.cleared from members m join chats c on c.id=m.chat_id where m.user_id=? and m.hidden=0', (uid,))
    out = []
    for c in rows:
        m = {'pinned': c['pinned'], 'muted': c['muted'], 'archived': c['archived'], 'folder': c['folder'], 'last_read': c['last_read'], 'role': c['mrole'], 'cleared': c['cleared']}
        out.append(chat_info(c, m, uid))
    ads = [dict(r) for r in q("select id,title,body,link from ads where status='approved' order by id desc limit 3")]
    fl = [dict(r) for r in q('select id,name from folders where user=?', (uid,))]
    return j({'chats': out, 'ads': ads, 'folders': fl, 'ai': S('ai_enabled', True), 'me': {'stars': u['stars'], 'premium_until': u['premium_until']}})


def find_private(a, b):
    r = q("select c.id from chats c join members x on x.chat_id=c.id and x.user_id=? join members y on y.chat_id=c.id and y.user_id=? where c.type='private'", (a, b), True)
    return r['id'] if r else None


@app.post('/api/chats/private')
def new_private():
    u = auth(); t = int((request.get_json(silent=True) or {}).get('user_id', 0)); tu = q('select * from users where id=? and banned=0', (t,), True)
    if not tu or t == u['id']: raise E('کاربر نامعتبر')
    cid = find_private(u['id'], t)
    if not cid:
        cid = x("insert into chats(type,created) values('private',?)", (now(),))
        db().executemany('insert into members(chat_id,user_id) values(?,?)', [(cid, u['id']), (cid, t)]); db().commit()
    else: x('update members set hidden=0 where chat_id=? and user_id=?', (cid, u['id']))
    return j({'id': cid})


@app.post('/api/chats/group')
def new_group():
    u = auth(); d = request.get_json(silent=True) or {}; typ = 'channel' if d.get('type') == 'channel' else 'group'
    title = (d.get('title') or '').strip()[:60]
    if not title: raise E('عنوان الزامی است')
    un = (d.get('username') or '').strip() or None; pub = 1 if d.get('public') and un else 0
    if un and (not UN.match(un) or q('select 1 from chats where username=?', (un,))): raise E('نام کاربری عمومی نامعتبر یا تکراری است')
    cid = x('insert into chats(type,title,owner,username,public,about,created) values(?,?,?,?,?,?,?)', (typ, title, u['id'], un if pub else None, pub, (d.get('about') or '')[:200], now()))
    db().execute("insert into members(chat_id,user_id,role) values(?,?,'owner')", (cid, u['id']))
    for i in set(int(i) for i in d.get('members', [])):
        if i != u['id'] and q('select 1 from users where id=?', (i,), True): db().execute("insert or ignore into members(chat_id,user_id) values(?,?)", (cid, i))
    db().commit(); ping(chat_ids(cid)); return j({'id': cid})


def chat_ids(cid): return [r['user_id'] for r in q('select user_id from members where chat_id=?', (cid,))]


@app.post('/api/join')
def join():
    u = auth(); d = request.get_json(silent=True) or {}
    c = q('select * from chats where id=? and public=1', (int(d.get('id', 0)),), True) or q('select * from chats where username=? and public=1', ((d.get('username') or '').lstrip('@'),), True)
    if not c: raise E('گفتگوی عمومی پیدا نشد', 404)
    x('insert or ignore into members(chat_id,user_id) values(?,?)', (c['id'], u['id'])); return j({'id': c['id']})


@app.route('/api/chats/<int:cid>', methods=['PUT'])
def edit_chat(cid):
    u = auth(); m = need_member(cid, u['id']); d = request.get_json(silent=True) or {}
    if m['role'] not in ('owner', 'admin'): raise E('فقط مدیران', 403)
    if d.get('title', '').strip(): x('update chats set title=? where id=?', (d['title'].strip()[:60], cid))
    if 'about' in d: x('update chats set about=? where id=?', ((d['about'] or '')[:200], cid))
    ping(chat_ids(cid)); return j()


@app.get('/api/chats/<int:cid>/members')
def members(cid):
    u = auth(); need_member(cid, u['id'])
    return j([dict(uj(r, u), mrole=r['role']) for r in q('select u.*,m.role from members m join users u on u.id=m.user_id where m.chat_id=? order by m.role desc, u.nick', (cid,))])


@app.post('/api/chats/<int:cid>/members')
def add_members(cid):
    u = auth(); m = need_member(cid, u['id']); d = request.get_json(silent=True) or {}
    if m['role'] not in ('owner', 'admin'): raise E('فقط مدیران', 403)
    for i in d.get('user_ids', []): x('insert or ignore into members(chat_id,user_id) values(?,?)', (cid, int(i)))
    if d.get('promote'): x("update members set role='admin' where chat_id=? and user_id=?", (cid, int(d['promote'])))
    ping(chat_ids(cid)); return j()


@app.delete('/api/chats/<int:cid>/members/<int:uid>')
def rm_member(cid, uid):
    u = auth(); m = need_member(cid, u['id'])
    if uid != u['id'] and m['role'] not in ('owner', 'admin'): raise E('فقط مدیران', 403)
    leave(cid, uid); return j()


def leave(cid, uid):
    c = q('select * from chats where id=?', (cid,), True)
    if c['type'] == 'private':
        last = q('select coalesce(max(id),0) n from messages where chat_id=?', (cid,), True)['n']
        x('update members set hidden=1, cleared=?, pinned=0 where chat_id=? and user_id=?', (last, cid, uid)); return
    x('delete from members where chat_id=? and user_id=?', (cid, uid))
    rest = q('select user_id from members where chat_id=? order by user_id', (cid,))
    if not rest:
        x('delete from messages where chat_id=?', (cid,)); x('delete from chats where id=?', (cid,))
    elif c['owner'] == uid:
        x('update chats set owner=? where id=?', (rest[0]['user_id'], cid)); x("update members set role='owner' where chat_id=? and user_id=?", (cid, rest[0]['user_id']))


@app.post('/api/chats/bulk')
def bulk():
    u = auth(); d = request.get_json(silent=True) or {}; ids = [int(i) for i in d.get('ids', [])]; a = d.get('action'); uid = u['id']
    for cid in ids:
        m = need_member(cid, uid)
        if a == 'mute': x('update members set muted=1 where chat_id=? and user_id=?', (cid, uid))
        elif a == 'unmute': x('update members set muted=0 where chat_id=? and user_id=?', (cid, uid))
        elif a == 'archive': x('update members set archived=1 where chat_id=? and user_id=?', (cid, uid))
        elif a == 'unarchive': x('update members set archived=0 where chat_id=? and user_id=?', (cid, uid))
        elif a == 'pin':
            lim = 15 if prem(u) else 5
            if not m['pinned'] and q('select count(*) n from members where user_id=? and pinned=1', (uid,), True)['n'] >= lim: raise E('سقف پین %d گفتگو است؛ با Premium بیشتر می‌شود' % lim, 402)
            x('update members set pinned=1 where chat_id=? and user_id=?', (cid, uid))
        elif a == 'unpin': x('update members set pinned=0 where chat_id=? and user_id=?', (cid, uid))
        elif a == 'read': x('update members set last_read=(select coalesce(max(id),0) from messages where chat_id=?) where chat_id=? and user_id=?', (cid, cid, uid))
        elif a == 'delete': leave(cid, uid)
        elif a == 'folder':
            f = d.get('folder')
            if f and not q('select 1 from folders where id=? and user=?', (int(f), uid), True): raise E('پوشه نامعتبر')
            x('update members set folder=? where chat_id=? and user_id=?', (f or None, cid, uid))
    return j()


@app.get('/api/folders')
def folders(): return j([dict(r) for r in q('select id,name from folders where user=?', (auth()['id'],))])


@app.post('/api/folders')
def add_folder():
    u = auth(); n = ((request.get_json(silent=True) or {}).get('name') or '').strip()[:30]
    lim = 10 if prem(u) else 3
    if not n: raise E('نام پوشه الزامی است')
    if q('select count(*) n from folders where user=?', (u['id'],), True)['n'] >= lim: raise E('سقف %d پوشه است؛ با Premium بیشتر می‌شود' % lim, 402)
    return j({'id': x('insert into folders(user,name) values(?,?)', (u['id'], n))})


@app.delete('/api/folders/<int:fid>')
def del_folder(fid):
    u = auth(); x('update members set folder=null where user_id=? and folder=?', (u['id'], fid)); x('delete from folders where id=? and user=?', (fid, u['id'])); return j()


# ---------------- messages ----------------
def add_msg(cid, u, text='', kind='text', file=None, reply=None, fwd=None, ttl=None, at=None, skip_checks=False):
    m = need_member(cid, u['id']); c = q('select * from chats where id=?', (cid,), True)
    if c['type'] == 'channel' and m['role'] not in ('owner', 'admin'): raise E('فقط مدیران کانال می‌توانند پست بگذارند', 403)
    if c['type'] == 'private':
        p = q('select user_id from members where chat_id=? and user_id!=?', (cid, u['id']), True)
        if p:
            if q('select 1 from blocks where owner=? and blocked=?', (p['user_id'], u['id']), True): raise E('این کاربر شما را مسدود کرده است', 403)
            pu = q('select privacy from users where id=?', (p['user_id'],), True)
            if jl(pu['privacy']).get('pm') == 'contacts' and not q('select 1 from contacts where owner=? and contact=?', (p['user_id'], u['id']), True): raise E('این کاربر فقط از مخاطبینش پیام می‌پذیرد', 403)
    if not skip_checks:
        if not rl('send%d' % u['id'], 60, 60): raise E('ارسال بیش از حد سریع است', 429)
        if kind not in ('text', 'image', 'video', 'file', 'voice', 'sticker'): raise E('نوع پیام نامعتبر')
        text = (text or '').strip()[:4000]
        if kind == 'text' and not text: raise E('پیام خالی است')
        if kind == 'sticker' and text not in STICKERS + (PSTICKERS if prem(u) else []): raise E('این استیکر مخصوص Premium است', 402)
        if kind in ('image', 'video', 'file', 'voice'):
            f = q('select * from files where name=? and owner=?', (file, u['id']), True)
            if not f or (f['kind'] != kind and not (kind == 'file' and f['kind'] == 'file')): raise E('فایل نامعتبر')
        if reply and not q('select 1 from messages where id=? and chat_id=?', (int(reply), cid), True): reply = None
    exp = None; created = now()
    if ttl and int(ttl) in (10, 60, 3600, 86400, 604800): exp = created + int(ttl)
    if at:
        at = int(at)
        if created < at <= created + 30 * 86400: created = at; exp = (created + int(ttl)) if exp else None
    mid = x('insert into messages(chat_id,sender,text,kind,file,reply_to,fwd,created,expire_at,upd) values(?,?,?,?,?,?,?,?,?,?)',
            (cid, u['id'], text, kind, file, reply, fwd, created, exp, seq()))
    x('update members set hidden=0 where chat_id=?', (cid,)); ping(chat_ids(cid)); return mid


MSQL = '''select m.*, u.nick sname, u.premium_until sp,
 (select text from messages where id=m.reply_to) rt, (select kind from messages where id=m.reply_to) rk,
 (select nick from users where id=(select sender from messages where id=m.reply_to)) rn from messages m join users u on u.id=m.sender '''


def mjs(rows, uid):
    ids = [r['id'] for r in rows]; R = {}
    if ids:
        for r in q('select msg_id,user_id,emoji from reactions where msg_id in (%s)' % ','.join('?' * len(ids)), ids):
            R.setdefault(r['msg_id'], {}).setdefault(r['emoji'], []).append(r['user_id'])
    out = []
    for r in rows:
        if r['deleted']: out.append({'id': r['id'], 'deleted': 1, 'upd': r['upd']}); continue
        f = q('select orig,size from files where name=?', (r['file'],), True) if r['file'] else None
        out.append({'id': r['id'], 'sender': r['sender'], 'sname': r['sname'], 'sprem': (r['sp'] or 0) > now(), 'text': r['text'], 'kind': r['kind'], 'file': r['file'],
                    'fname': f['orig'] if f else None, 'fsize': f['size'] if f else None, 'reply': {'id': r['reply_to'], 'text': r['rt'] if r['rk'] == 'text' else {'image': '🖼 تصویر', 'video': '🎬 ویدیو', 'voice': '🎤 صوتی', 'file': '📎 فایل'}.get(r['rk'], r['rt']), 'name': r['rn']} if r['reply_to'] and r['rn'] else None,
                    'fwd': r['fwd'], 'edited': r['edited'], 'pinned': r['pinned'], 'created': r['created'], 'expire': r['expire_at'], 'upd': r['upd'], 'rx': R.get(r['id'], {})})
    return out


@app.get('/api/chats/<int:cid>/messages')
def get_msgs(cid):
    u = auth(); m = need_member(cid, u['id']); a = request.args
    cur = db().execute('select n from ctr').fetchone()[0]; n = now()
    since = int(a.get('since', 0)); ts = int(a.get('ts', 0)); before = int(a.get('before', 0)); s = (a.get('q') or '').strip()
    sql = MSQL + 'where m.chat_id=? and m.id>? and m.created<=? and (m.expire_at is null or m.expire_at>?)'; args = [cid, m['cleared'], n, n]
    if s: sql += " and m.deleted=0 and m.text like ? escape '\\'"; args.append('%' + s.replace('\\', '').replace('%', '\\%').replace('_', '\\_') + '%')
    if since: rows = q(sql + ' and (m.upd>? or (m.created>? and m.created<=?)) order by m.id', args + [since, ts, n])
    else:
        if before: sql += ' and m.id<?'; args.append(before)
        rows = list(reversed(q(sql + ' order by m.id desc limit 50', args)))
    others = q('select m.last_read,m.delivered,u.privacy,u.premium_until from members m join users u on u.id=m.user_id where m.chat_id=? and m.user_id!=?', (cid, u['id']))
    pr = max([o['last_read'] for o in others if not (jl(o['privacy']).get('receipts') == 'off' and (o['premium_until'] or 0) > n)] or [0])
    pd = max([o['delivered'] for o in others] or [0])
    pins = [{'id': r['id'], 'text': r['text'] or '📎'} for r in q('select id,text from messages where chat_id=? and pinned=1 and deleted=0 order by id desc limit 5', (cid,))]
    return j({'messages': mjs(rows, u['id']), 'upd': cur, 'ts': n, 'peer_read': pr, 'peer_delivered': pd, 'pins': pins, 'role': m['role']})


@app.post('/api/chats/<int:cid>/messages')
def send_msg(cid):
    u = auth(); d = request.get_json(silent=True) or {}
    mid = add_msg(cid, u, d.get('text'), d.get('kind', 'text'), d.get('file'), d.get('reply_to'), None, d.get('ttl'), d.get('at'))
    return j({'id': mid})


@app.post('/api/chats/<int:cid>/read')
def mark_read(cid):
    u = auth(); need_member(cid, u['id'])
    x('update members set last_read=(select coalesce(max(id),0) from messages where chat_id=? and created<=?) where chat_id=? and user_id=?', (cid, now(), cid, u['id']))
    ping(chat_ids(cid)); return j()


def get_msg(mid, uid):
    r = q('select * from messages where id=? and deleted=0', (mid,), True)
    if not r: raise E('پیام یافت نشد', 404)
    return r, need_member(r['chat_id'], uid)


@app.route('/api/messages/<int:mid>', methods=['PUT', 'DELETE'])
def msg_edit(mid):
    u = auth(); r, m = get_msg(mid, u['id'])
    if request.method == 'PUT':
        t = ((request.get_json(silent=True) or {}).get('text') or '').strip()[:4000]
        if r['sender'] != u['id'] or r['kind'] != 'text' or not t: raise E('امکان ویرایش نیست', 403)
        x('update messages set text=?, edited=1, upd=? where id=?', (t, seq(), mid))
    else:
        if r['sender'] != u['id'] and m['role'] not in ('owner', 'admin'): raise E('امکان حذف نیست', 403)
        x("update messages set deleted=1, text='', file=null, upd=? where id=?", (seq(), mid))
    ping(chat_ids(r['chat_id'])); return j()


@app.post('/api/messages/<int:mid>/react')
def react(mid):
    u = auth(); r, m = get_msg(mid, u['id']); e = (request.get_json(silent=True) or {}).get('emoji')
    if e not in REACT + PREACT: raise E('واکنش نامعتبر')
    if e in PREACT and not prem(u): raise E('این واکنش مخصوص Premium است', 402)
    old = q('select emoji from reactions where msg_id=? and user_id=?', (mid, u['id']), True)
    if old and old['emoji'] == e: db().execute('delete from reactions where msg_id=? and user_id=?', (mid, u['id']))
    else: db().execute('insert or replace into reactions values(?,?,?)', (mid, u['id'], e))
    db().execute('update messages set upd=? where id=?', (seq(), mid)); db().commit(); ping(chat_ids(r['chat_id'])); return j()


@app.post('/api/messages/<int:mid>/pin')
def pin_msg(mid):
    u = auth(); r, m = get_msg(mid, u['id']); c = q('select type from chats where id=?', (r['chat_id'],), True)
    if c['type'] != 'private' and m['role'] not in ('owner', 'admin'): raise E('فقط مدیران', 403)
    x('update messages set pinned=1-pinned, upd=? where id=?', (seq(), mid)); ping(chat_ids(r['chat_id'])); return j()


@app.post('/api/messages/<int:mid>/forward')
def forward(mid):
    u = auth(); r, m = get_msg(mid, u['id']); src = q('select nick from users where id=?', (r['sender'],), True)['nick']
    for cid in (request.get_json(silent=True) or {}).get('chats', []):
        x_ = add_msg(int(cid), u, r['text'], r['kind'], None, None, src, skip_checks=True)
        if r['file']:
            f = q('select * from files where name=?', (r['file'],), True)
            x('update messages set file=? where id=?', (r['file'], x_))
    return j()


@app.post('/api/report')
def report():
    u = auth(); d = request.get_json(silent=True) or {}
    if d.get('kind') not in ('user', 'message', 'chat'): raise E('نامعتبر')
    x('insert into reports(reporter,kind,target,reason,created) values(?,?,?,?,?)', (u['id'], d['kind'], int(d.get('target', 0)), (d.get('reason') or '')[:300], now())); return j()


# ---------------- premium / stars / gifts / ads ----------------
@app.get('/api/wallet')
def wallet():
    u = auth(); plans = S('plans', PLANS)
    tx = [dict(r) for r in q('select delta,reason,created from stars_tx where user=? order by id desc limit 60', (u['id'],))]
    return j({'stars': u['stars'], 'tx': tx, 'plans': plans, 'premium_until': u['premium_until'], 'daily_ready': now() - (u['daily'] or 0) >= 86400,
              'gifts': [dict(r) for r in q('select * from gifts where active=1 order by price')], 'ad_cost': S('ad_cost', 100),
              'packs': STAR_PACKS, 'shop': S('stars_shop', 'demo')})


@app.post('/api/stars/buy')
def buy_stars():
    u = auth(); d = request.get_json(silent=True) or {}
    if S('stars_shop', 'demo') != 'demo': raise E('خرید استارز فعلاً غیرفعال است', 403)
    try: n = int(d.get('pack', 0))
    except Exception: raise E('بستهٔ نامعتبر')
    if n not in STAR_PACKS: raise E('بستهٔ نامعتبر')
    if not rl('buys%d' % u['id'], 10, 3600): raise E('تعداد خرید بیش از حد مجاز است', 429)
    db().execute('begin immediate'); stars_move(u['id'], n, 'خرید بستهٔ %d استارز (آزمایشی)' % n); db().commit()
    return j({'amount': n})


@app.post('/api/stars/daily')
def daily():
    u = auth(); db().execute('begin immediate')
    if now() - (u['daily'] or 0) < 86400: db().rollback(); raise E('پاداش امروز را گرفته‌اید')
    amt = 25 if prem(u) else 10; db().execute('update users set daily=? where id=?', (now(), u['id'])); stars_move(u['id'], amt, 'پاداش روزانه'); db().commit()
    return j({'amount': amt})


@app.post('/api/stars/send')
def send_stars():
    u = auth(); d = request.get_json(silent=True) or {}; db().execute('begin immediate')
    try: amt = int(d.get('amount', 0)); t = int(d.get('to', 0))
    except Exception: raise E('مقدار نامعتبر')
    if amt <= 0 or amt > 100000 or t == u['id'] or not q('select 1 from users where id=? and banned=0', (t,), True): db().rollback(); raise E('مقدار یا گیرنده نامعتبر است')
    stars_move(u['id'], -amt, 'ارسال به کاربر #%d' % t); stars_move(t, amt, 'دریافت از %s' % u['nick']); db().commit(); ping([t]); return j()


@app.post('/api/premium/buy')
def buy_premium():
    u = auth(); d = request.get_json(silent=True) or {}; plans = S('plans', PLANS); p = plans.get(d.get('plan')); to = int(d.get('to') or u['id'])
    if not p or not q('select 1 from users where id=? and banned=0', (to,), True): raise E('پلن یا کاربر نامعتبر')
    db().execute('begin immediate'); stars_move(u['id'], -p[1], 'خرید Premium %d روزه%s' % (p[0], '' if to == u['id'] else ' (هدیه به #%d)' % to))
    add_premium(to, p[0]); db().commit(); ping([to]); return j()


@app.post('/api/gifts/send')
def send_gift():
    u = auth(); d = request.get_json(silent=True) or {}; gf = q('select * from gifts where id=? and active=1', (int(d.get('gift', 0)),), True); to = int(d.get('to', 0))
    if not gf or to == u['id'] or not q('select 1 from users where id=? and banned=0', (to,), True): raise E('هدیه یا گیرنده نامعتبر')
    if gf['premium_only'] and not prem(u): raise E('این هدیه مخصوص Premium است', 402)
    db().execute('begin immediate'); stars_move(u['id'], -gf['price'], 'هدیه %s به #%d' % (gf['name'], to))
    db().execute('insert into user_gifts(to_user,from_user,gift,note,created) values(?,?,?,?,?)', (to, u['id'], gf['id'], (d.get('note') or '')[:100], now())); db().commit()
    cid = find_private(u['id'], to)
    if cid:
        try: add_msg(cid, u, '%s|%s|%d|%s' % (gf['emoji'], gf['name'], gf['price'], (d.get('note') or '')[:100].replace('|', ' ')), 'gift', skip_checks=True)
        except E: pass
    ping([to]); return j()


@app.post('/api/ads')
def new_ad():
    u = auth(); d = request.get_json(silent=True) or {}; t = (d.get('title') or '').strip()[:60]; b = (d.get('body') or '').strip()[:140]; l = (d.get('link') or '').strip()[:200]
    if not t or not b: raise E('عنوان و متن تبلیغ الزامی است')
    if l and not re.match(r'^https?://', l): raise E('لینک باید با http یا https شروع شود')
    db().execute('begin immediate'); stars_move(u['id'], -S('ad_cost', 100), 'درخواست تبلیغ')
    aid = db().execute('insert into ads(user,title,body,link,created) values(?,?,?,?,?)', (u['id'], t, b, l, now())).lastrowid; db().commit(); return j({'id': aid})


@app.get('/api/ads/mine')
def my_ads(): return j([dict(r) for r in q('select id,title,body,status,views,clicks from ads where user=? order by id desc', (auth()['id'],))])


@app.post('/api/ads/<int:aid>/<ev>')
def ad_event(aid, ev):
    auth()
    if ev in ('views', 'clicks'): x('update ads set %s=%s+1 where id=? and status=?' % (ev, ev), (aid, 'approved'))
    return j()


# ---------------- AI ----------------
AI_MODELS = ['openai/gpt-4o-mini', 'google/gemini-2.0-flash-001', 'meta-llama/llama-3.3-70b-instruct', 'anthropic/claude-3.5-haiku', 'deepseek/deepseek-chat']


def llm(messages, model, uid):
    key = os.environ.get('NEXO_OPENROUTER_KEY') or S('openrouter_key')
    if not key: raise E('کلید OpenRouter روی سرور تنظیم نشده است (متغیر NEXO_OPENROUTER_KEY یا پنل مدیریت ← هوش مصنوعی).', 503)
    req = urllib.request.Request('https://openrouter.ai/api/v1/chat/completions', json.dumps({'model': model, 'messages': messages}).encode(),
                                 {'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json', 'HTTP-Referer': 'http://localhost', 'X-Title': 'NEXO'})
    try: r = json.load(urllib.request.urlopen(req, timeout=75))
    except Exception as e: raise E('اتصال به OpenRouter ناموفق بود: %s' % str(e)[:80], 502)
    tok = (r.get('usage') or {}).get('total_tokens', 0)
    x('insert into ai_usage(user,model,tokens,created) values(?,?,?,?)', (uid, model, tok, now()))
    try: return r['choices'][0]['message']['content']
    except Exception: raise E('پاسخ نامعتبر از مدل', 502)


def ai_gate(u):
    if not S('ai_enabled', True): raise E('NEXO AI توسط مدیر غیرفعال شده است', 503)
    rate = S('ai_rate', 30); rate = rate if prem(u) else max(5, rate // 3)
    if not rl('ai%d' % u['id'], rate, 3600): raise E('سقف درخواست ساعتی AI تمام شد' + ('' if prem(u) else ' (Premium سقف بیشتری دارد)'), 429)


def ai_model(u, want):
    ms = S('ai_models', AI_MODELS); dm = S('ai_model', ms[0])
    return want if (want in ms and prem(u)) else (jl(u['ai_prefs']).get('model') if jl(u['ai_prefs']).get('model') in ms and prem(u) else dm)


def system_prompt(u):
    pf = jl(u['ai_prefs']); mem = [r['text'] for r in q('select text from ai_mem where user=? order by id desc limit 30', (u['id'],))]
    s = 'تو NEXO AI هستی، دستیار هوشمند داخل پیام‌رسان NEXO. به زبان کاربر (پیش‌فرض فارسی) مفید، دقیق و مختصر پاسخ بده. برای برنامه‌نویسی کد کامل و توضیح خطاها را بده.'
    if pf.get('persona'): s += '\nشخصیت/رفتار دلخواه کاربر: ' + pf['persona'][:400]
    if mem: s += '\nچیزهایی که درباره کاربر به خاطر داری:\n- ' + '\n- '.join(mem)
    return s


@app.get('/api/ai/state')
def ai_state():
    u = auth()
    return j({'history': [dict(r) for r in reversed(q('select role,content,created from ai_msgs where user=? order by id desc limit 60', (u['id'],)))],
              'mem': [dict(r) for r in q('select id,text from ai_mem where user=? order by id desc', (u['id'],))], 'prefs': jl(u['ai_prefs']),
              'models': S('ai_models', AI_MODELS), 'model': ai_model(u, None), 'enabled': S('ai_enabled', True), 'premium': prem(u), 'has_key': bool(os.environ.get('NEXO_OPENROUTER_KEY') or S('openrouter_key'))})


@app.post('/api/ai/chat')
def ai_chat():
    u = auth(); d = request.get_json(silent=True) or {}; t = (d.get('text') or '').strip()[:4000]
    if not t: raise E('پیام خالی است')
    ai_gate(u)
    m = re.match(r'^(یادت باشه|به خاطر بسپار)[:：،\s]+(.+)$', t, re.S)
    if m and q('select count(*) n from ai_mem where user=?', (u['id'],), True)['n'] < 60: x('insert into ai_mem(user,text) values(?,?)', (u['id'], m.group(2)[:300]))
    hist = [{'role': r['role'], 'content': r['content']} for r in reversed(q('select role,content from ai_msgs where user=? order by id desc limit 16', (u['id'],)))]
    ans = llm([{'role': 'system', 'content': system_prompt(u)}] + hist + [{'role': 'user', 'content': t}], ai_model(u, d.get('model')), u['id'])
    x('insert into ai_msgs(user,role,content,created) values(?,?,?,?)', (u['id'], 'user', t, now())); x('insert into ai_msgs(user,role,content,created) values(?,?,?,?)', (u['id'], 'assistant', ans, now()))
    return j({'answer': ans})


@app.post('/api/ai/analyze')
def ai_analyze():
    u = auth(); d = request.get_json(silent=True) or {}; cid = int(d.get('chat_id', 0)); m = need_member(cid, u['id']); ai_gate(u)
    rows = q('select u.nick,m.text from messages m join users u on u.id=m.sender where m.chat_id=? and m.id>? and m.deleted=0 and m.kind="text" order by m.id desc limit 40', (cid, m['cleared']))
    if not rows: raise E('پیامی برای تحلیل نیست')
    txt = '\n'.join('%s: %s' % (r['nick'], r['text'][:300]) for r in reversed(rows))
    ans = llm([{'role': 'system', 'content': 'گفتگوی زیر را به فارسی تحلیل کن: خلاصه، موضوعات اصلی، لحن، کارهای باقی‌مانده. مختصر و ساختارمند.'}, {'role': 'user', 'content': txt}], ai_model(u, None), u['id'])
    return j({'answer': ans})


@app.post('/api/ai/mem')
def ai_mem():
    u = auth(); d = request.get_json(silent=True) or {}
    if d.get('delete'): x('delete from ai_mem where id=? and user=?', (int(d['delete']), u['id']))
    elif d.get('text'): x('insert into ai_mem(user,text) values(?,?)', (u['id'], d['text'][:300]))
    return j()


@app.post('/api/ai/prefs')
def ai_prefs():
    u = auth(); d = request.get_json(silent=True) or {}; pf = jl(u['ai_prefs'])
    if 'persona' in d: pf['persona'] = (d['persona'] or '')[:400]
    if d.get('model') in S('ai_models', AI_MODELS):
        if not prem(u): raise E('انتخاب مدل مخصوص Premium است', 402)
        pf['model'] = d['model']
    x('update users set ai_prefs=? where id=?', (json.dumps(pf, ensure_ascii=False), u['id'])); return j()


@app.delete('/api/ai/history')
def ai_clear(): x('delete from ai_msgs where user=?', (auth()['id'],)); return j()


# ---------- AI UI designer (theme system, no arbitrary code) ----------
HEX = re.compile(r'^#[0-9a-fA-F]{6}$')
def clean_theme(t, premium=True):
    o = {}
    if not isinstance(t, dict): return o
    if t.get('mode') in ('dark', 'light'): o['mode'] = t['mode']
    for k in ('accent', 'accent2', 'bg', 'surface', 'text'):
        if isinstance(t.get(k), str) and HEX.match(t[k]): o[k] = t[k].lower()
    try:
        if 'radius' in t: o['radius'] = max(0, min(28, int(t['radius'])))
        if 'scale' in t: o['scale'] = max(.85, min(1.3, float(t['scale'])))
        if 'anim' in t: o['anim'] = max(0, min(2, int(t['anim'])))
    except Exception: pass
    if t.get('nav') in ('bottom', 'floating', 'compact'): o['nav'] = t['nav']
    if t.get('bubble') in ('gradient', 'flat'): o['bubble'] = t['bubble']
    if 'glass' in t: o['glass'] = bool(t['glass'])
    if not premium: o = {k: v for k, v in o.items() if k in ('mode', 'accent')}
    return o


COL = {'بنفش': ('#8b5cf6', '#c084fc'), 'آبی': ('#3b82f6', '#60a5fa'), 'قرمز': ('#ef4444', '#f87171'), 'سبز': ('#10b981', '#34d399'), 'نارنجی': ('#f97316', '#fb923c'),
       'صورتی': ('#ec4899', '#f472b6'), 'زرد': ('#eab308', '#facc15'), 'فیروزه': ('#14b8a6', '#2dd4bf'), 'طلایی': ('#d4a017', '#f5c542')}


def rule_theme(p):
    t = {}
    if 'مشکی' in p: t.update(mode='dark', bg='#050508', surface='#101016')
    elif re.search('سفید|روشن', p): t['mode'] = 'light'
    elif re.search('تیره|شب', p): t['mode'] = 'dark'
    for k, (a, b) in COL.items():
        if k in p: t.update(accent=a, accent2=b); break
    if 'شیشه' in p: t['glass'] = True
    if 'انیمیشن' in p: t['anim'] = 0 if re.search('کمتر|بدون|خاموش', p) else 2
    if 'منوی پایین' in p or 'منو' in p: t['nav'] = 'compact' if re.search('فشرده|کوچک', p) else 'floating'
    if re.search('گرد', p): t['radius'] = 24
    if re.search('تیز|مربع', p): t['radius'] = 4
    if re.search('فونت.*(بزرگ|درشت)|بزرگ‌تر', p): t['scale'] = 1.15
    if 'ساده' in p or 'تخت' in p: t['bubble'] = 'flat'
    return t


@app.post('/api/ai/theme')
def ai_theme():
    u = auth(); d = request.get_json(silent=True) or {}; p = (d.get('prompt') or '').strip()[:300]
    if not prem(u): raise E('AI UI Designer مخصوص کاربران Premium است', 402)
    if not p: raise E('دستور خالی است')
    ai_gate(u); eng = 'rules'; note = 'تغییرات بر اساس دستور شما تنظیم شد.'; t = None
    if (os.environ.get('NEXO_OPENROUTER_KEY') or S('openrouter_key')) and S('ai_enabled', True):
        sysm = ('تو طراح رابط NEXO هستی. فقط یک شیء JSON برگردان با کلیدهای مجاز: mode(dark|light), accent, accent2, bg, surface, text (هگز #rrggbb), radius(0-28), '
                'scale(0.85-1.3), anim(0|1|2), nav(bottom|floating|compact), bubble(gradient|flat), glass(true|false), note(توضیح کوتاه فارسی). فقط کلیدهای لازم را بده. هیچ کد یا متن دیگری ننویس.')
        try:
            raw = llm([{'role': 'system', 'content': sysm}, {'role': 'user', 'content': p}], ai_model(u, None), u['id'])
            m = re.search(r'\{.*\}', raw, re.S); o = json.loads(m.group(0)); note = str(o.get('note') or note)[:200]; t = clean_theme(o); eng = 'ai'
        except Exception: t = None
    if not t: t = clean_theme(rule_theme(p))
    if not t: raise E('متوجه تغییر مورد نظر نشدم؛ مثلاً بنویسید: «مشکی و بنفش کن» یا «حالت شیشه‌ای»')
    return j({'theme': t, 'note': note, 'engine': eng})


@app.post('/api/theme')
def save_theme():
    u = auth(); d = request.get_json(silent=True) or {}
    t = None if d.get('theme') is None else clean_theme(d['theme'], prem(u))
    x('update users set theme=? where id=?', (json.dumps(t) if t else None, u['id'])); return j({'theme': t})


# ---------------- admin API ----------------
def A(level='mod'): return adm(level)


@app.get('/api/admin/stats')
def a_stats():
    A(); n = now(); c = lambda s, a=(): q(s, a, True)[0]
    return j({'users': c('select count(*) from users'), 'online': c('select count(*) from users where last_seen>?', (n - 60,)), 'messages': c('select count(*) from messages where deleted=0'),
              'groups': c("select count(*) from chats where type='group'"), 'channels': c("select count(*) from chats where type='channel'"), 'premium': c('select count(*) from users where premium_until>?', (n,)),
              'stars': c('select coalesce(sum(stars),0) from users'), 'ads': c('select count(*) from ads'), 'ads_pending': c("select count(*) from ads where status='pending'"), 'ad_views': c('select coalesce(sum(views),0) from ads'),
              'ai_requests': c('select count(*) from ai_usage'), 'ai_tokens': c('select coalesce(sum(tokens),0) from ai_usage'), 'reports': c("select count(*) from reports where status='open'"), 'banned': c('select count(*) from users where banned=1')})


@app.get('/api/admin/users')
def a_users():
    A(); s = (request.args.get('q') or '').strip(); like = '%' + s + '%'
    rows = q('select * from users where username like ? or nick like ? or phone like ? or id=? order by id desc limit 60', (like, like, like, int(s) if s.isdigit() else -1)) if s else q('select * from users order by id desc limit 60')
    return j([{'id': r['id'], 'username': r['username'], 'nick': r['nick'], 'phone': r['phone'], 'role': r['role'], 'banned': r['banned'], 'stars': r['stars'], 'premium_until': r['premium_until'], 'created': r['created'], 'last_seen': r['last_seen']} for r in rows])


@app.get('/api/admin/users/<int:uid>')
def a_user(uid):
    A(); r = q('select * from users where id=?', (uid,), True)
    if not r: raise E('یافت نشد', 404)
    return j({'user': {k: r[k] for k in ('id', 'username', 'nick', 'phone', 'bio', 'birth', 'role', 'banned', 'stars', 'premium_until', 'created', 'last_seen')},
              'tx': [dict(t) for t in q('select s.delta,s.reason,s.created,a.nick admin from stars_tx s left join users a on a.id=s.admin where s.user=? order by s.id desc limit 40', (uid,))],
              'messages': q('select count(*) n from messages where sender=?', (uid,), True)['n']})


@app.post('/api/admin/users/<int:uid>')
def a_user_op(uid):
    d = request.get_json(silent=True) or {}; op = d.get('op'); reason = (d.get('reason') or '').strip()[:200]
    t = q('select * from users where id=?', (uid,), True)
    if not t: raise E('یافت نشد', 404)
    lvl = 'owner' if op == 'role' else ('admin' if op in ('premium', 'revoke', 'stars', 'delete') else 'mod'); a = A(lvl)
    if LV[t['role']] >= LV[a['role']] and t['id'] != a['id'] and a['role'] != 'owner': raise E('نمی‌توانید روی هم‌سطح یا بالاتر عمل کنید', 403)
    if op in ('premium', 'revoke', 'stars', 'delete', 'ban', 'role') and not reason: raise E('ثبت دلیل الزامی است')
    if op == 'ban':
        if t['id'] == a['id']: raise E('نمی‌توانید خودتان را مسدود کنید')
        x('update users set banned=1 where id=?', (uid,)); x('update sessions set revoked=1 where user=?', (uid,))
    elif op == 'unban': x('update users set banned=0 where id=?', (uid,))
    elif op == 'premium': add_premium(uid, max(1, min(3650, int(d.get('days', 30))))); db().commit(); ping([uid])
    elif op == 'revoke': x('update users set premium_until=0 where id=?', (uid,))
    elif op == 'stars':
        amt = int(d.get('amount', 0))
        if amt == 0 or abs(amt) > 1000000: raise E('مقدار نامعتبر')
        db().execute('begin immediate'); stars_move(uid, amt, 'مدیر: ' + reason, a['id']); db().commit(); ping([uid])
    elif op == 'role':
        if d.get('role') not in LV or d['role'] == 'owner' or t['role'] == 'owner': raise E('نقش نامعتبر')
        x('update users set role=? where id=?', (d['role'], uid))
    elif op == 'delete':
        if t['role'] == 'owner': raise E('حذف مدیر اصلی ممکن نیست')
        for tb, col in (('sessions', 'user'), ('members', 'user_id'), ('contacts', 'owner'), ('blocks', 'owner'), ('folders', 'user'), ('posts', 'user'), ('ai_msgs', 'user'), ('ai_mem', 'user')): db().execute('delete from %s where %s=?' % (tb, col), (uid,))
        db().execute("update messages set deleted=1, text='', file=null, upd=? where sender=?", (seq(), uid)); db().execute('delete from users where id=?', (uid,)); db().commit()
    else: raise E('عملیات نامعتبر')
    audit('admin', op + ' user#%d' % uid, reason or d.get('amount', ''), a['id']); return j()


@app.get('/api/admin/chats')
def a_chats():
    A(); return j([dict(r) for r in q("select c.id,c.type,c.title,c.username,c.public,c.created,(select count(*) from members where chat_id=c.id) members,(select count(*) from messages where chat_id=c.id) msgs from chats c where c.type!='private' order by c.id desc limit 100")])


@app.delete('/api/admin/chats/<int:cid>')
def a_chat_del(cid):
    a = A(); x('delete from messages where chat_id=?', (cid,)); x('delete from members where chat_id=?', (cid,)); x('delete from chats where id=?', (cid,)); audit('admin', 'delete chat#%d' % cid, '', a['id']); return j()


@app.get('/api/admin/ads')
def a_ads(): A(); return j([dict(r) for r in q('select a.*,u.username from ads a join users u on u.id=a.user order by a.id desc limit 100')])


@app.post('/api/admin/ads/<int:aid>')
def a_ad_op(aid):
    a = A(); op = (request.get_json(silent=True) or {}).get('op'); ad = q('select * from ads where id=?', (aid,), True)
    if not ad: raise E('یافت نشد', 404)
    if op == 'approve': x("update ads set status='approved' where id=?", (aid,))
    elif op in ('reject', 'delete'):
        if ad['status'] == 'pending':
            db().execute('begin immediate'); stars_move(ad['user'], S('ad_cost', 100), 'بازگشت هزینه تبلیغ رد شده', a['id']); db().commit()
        x("update ads set status='rejected' where id=?" if op == 'reject' else 'delete from ads where id=?', (aid,))
    else: raise E('نامعتبر')
    audit('admin', '%s ad#%d' % (op, aid), '', a['id']); return j()


@app.get('/api/admin/reports')
def a_reports(): A(); return j([dict(r) for r in q('select r.*,u.username from reports r join users u on u.id=r.reporter order by r.status, r.id desc limit 100')])


@app.post('/api/admin/reports/<int:rid>')
def a_report_op(rid): a = A(); x("update reports set status='closed' where id=?", (rid,)); audit('admin', 'close report#%d' % rid, '', a['id']); return j()


@app.get('/api/admin/gifts')
def a_gifts(): A(); return j([dict(r) for r in q('select * from gifts order by id')])


@app.post('/api/admin/gifts')
def a_gift_save():
    a = A('admin'); d = request.get_json(silent=True) or {}
    if d.get('id'): x('update gifts set price=?, active=? where id=?', (max(1, int(d['price'])), int(bool(d.get('active', 1))), int(d['id'])))
    else: x('insert into gifts(name,emoji,price,premium_only,rare) values(?,?,?,?,?)', ((d.get('name') or '')[:20], (d.get('emoji') or '🎁')[:4], max(1, int(d.get('price', 10))), int(bool(d.get('premium_only'))), int(bool(d.get('rare')))))
    audit('admin', 'gift save', d, a['id']); return j()


@app.get('/api/admin/ai')
def a_ai():
    A('admin'); k = os.environ.get('NEXO_OPENROUTER_KEY') or S('openrouter_key')
    return j({'enabled': S('ai_enabled', True), 'model': S('ai_model', AI_MODELS[0]), 'models': S('ai_models', AI_MODELS), 'rate': S('ai_rate', 30), 'key': ('••••' + k[-4:]) if k else '',
              'usage': [dict(r) for r in q('select u.username,count(*) n,sum(t.tokens) tok from ai_usage t join users u on u.id=t.user group by t.user order by tok desc limit 20')]})


@app.post('/api/admin/ai')
def a_ai_set():
    a = A('admin'); d = request.get_json(silent=True) or {}
    if 'enabled' in d: setS('ai_enabled', bool(d['enabled']))
    if d.get('models'): setS('ai_models', [m.strip() for m in d['models'] if m.strip()][:20])
    if d.get('model'): setS('ai_model', d['model'])
    if d.get('rate'): setS('ai_rate', max(1, min(1000, int(d['rate']))))
    if d.get('key'): setS('openrouter_key', d['key'].strip())
    audit('admin', 'ai settings', {k: v for k, v in d.items() if k != 'key'}, a['id']); return j()


@app.get('/api/admin/system')
def a_system():
    A('admin')
    return j({'errors': [dict(r) for r in q('select * from errors order by id desc limit 30')], 'audit': [dict(r) for r in q('select a.*,u.username from audit a left join users u on u.id=a.actor order by a.id desc limit 80')],
              'backups': sorted(os.listdir(BK))[-10:], 'settings': {'reg_open': S('reg_open', True), 'rules': S('rules', RULES), 'ad_cost': S('ad_cost', 100), 'plans': S('plans', PLANS), 'stars_shop': S('stars_shop', 'demo')}})


@app.post('/api/admin/system')
def a_system_set():
    d = request.get_json(silent=True) or {}; a = A('owner' if d.get('op') == 'backup' else 'admin')
    if d.get('op') == 'backup':
        name = 'nexo-%s.db' % time.strftime('%Y%m%d-%H%M%S'); src = sqlite3.connect(DB); dst = sqlite3.connect(os.path.join(BK, name)); src.backup(dst); dst.close(); src.close()
    else:
        if 'reg_open' in d: setS('reg_open', bool(d['reg_open']))
        if d.get('rules'): setS('rules', d['rules'][:3000])
        if d.get('ad_cost'): setS('ad_cost', max(0, int(d['ad_cost'])))
        if d.get('stars_shop') in ('demo', 'off'): setS('stars_shop', d['stars_shop'])
        if d.get('plans'): setS('plans', {k: [int(v[0]), int(v[1])] for k, v in d['plans'].items() if k in PLANS})
    audit('admin', 'system ' + str(d.get('op', 'settings')), '', a['id']); return j()


@app.get('/api/admin/backup/<name>')
def a_backup_dl(name):
    A('owner'); return send_from_directory(BK, os.path.basename(name), as_attachment=True)


def purge():
    while True:
        time.sleep(60)
        try:
            c = sqlite3.connect(DB); c.execute('delete from messages where expire_at is not null and expire_at<?', (now(),)); c.commit(); c.close()
        except Exception: pass


